export const base_url = `https://api.openweathermap.org/data/2.5/weather`;
export const api_key = `5052885cf7b9dad5395aa30169d4ab27`;
export const cache_time = 60 * 1000;